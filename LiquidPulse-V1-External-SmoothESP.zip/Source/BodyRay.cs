using System;
using System.Collections.Generic;
using System.IO;
namespace LiquidPulse {
public static class CrosshairRay {
 public static bool Direction(float[] matrix,double x,double y,V3 origin,out V3 direction){
 direction=new V3();if(matrix==null||matrix.Length!=16||double.IsNaN(x)||double.IsNaN(y)||double.IsInfinity(x)||double.IsInfinity(y))return false;
 foreach(float value in matrix)if(float.IsNaN(value)||float.IsInfinity(value))return false;
 var a=new double[4,8];for(int i=0;i<4;i++)for(int j=0;j<4;j++){a[i,j]=matrix[i*4+j];a[i,j+4]=i==j?1:0;}
 for(int col=0;col<4;col++){int pivot=col;for(int r=col+1;r<4;r++)if(Math.Abs(a[r,col])>Math.Abs(a[pivot,col]))pivot=r;if(Math.Abs(a[pivot,col])<1e-12)return false;for(int j=0;j<8;j++){double t=a[col,j];a[col,j]=a[pivot,j];a[pivot,j]=t;}double v=a[col,col];for(int j=0;j<8;j++)a[col,j]/=v;for(int r=0;r<4;r++){if(r==col)continue;v=a[r,col];for(int j=0;j<8;j++)a[r,j]-=v*a[col,j];}}
 double[] clip={x,y,0.5,1},world=new double[4];for(int i=0;i<4;i++)for(int j=0;j<4;j++)world[i]+=a[i,j+4]*clip[j];if(Math.Abs(world[3])<1e-12)return false;
 double dx=world[0]/world[3]-origin.X,dy=world[1]/world[3]-origin.Y,dz=world[2]/world[3]-origin.Z;double length=Math.Sqrt(dx*dx+dy*dy+dz*dz);if(length<1e-9||double.IsNaN(length)||double.IsInfinity(length))return false;direction=new V3((float)(dx/length),(float)(dy/length),(float)(dz/length));return true;
 }
 public static bool Entry(WallBox box,V3 origin,V3 direction,double maximum,out double distance){
 distance=0;if(box==null||box.Rotation==null||box.Rotation.Length!=9||maximum<=0||double.IsNaN(maximum)||double.IsInfinity(maximum)||box.Half.X<0||box.Half.Y<0||box.Half.Z<0||float.IsNaN(box.Half.X)||float.IsNaN(box.Half.Y)||float.IsNaN(box.Half.Z)||float.IsInfinity(box.Half.X)||float.IsInfinity(box.Half.Y)||float.IsInfinity(box.Half.Z))return false;
 double ax=origin.X-box.Center.X,ay=origin.Y-box.Center.Y,az=origin.Z-box.Center.Z,enter=0,exit=maximum;
 for(int axis=0;axis<3;axis++){double p=ax*box.Rotation[axis]+ay*box.Rotation[axis+3]+az*box.Rotation[axis+6],v=direction.X*box.Rotation[axis]+direction.Y*box.Rotation[axis+3]+direction.Z*box.Rotation[axis+6],half=axis==0?box.Half.X:axis==1?box.Half.Y:box.Half.Z;
 if(double.IsNaN(p)||double.IsInfinity(p)||double.IsNaN(v)||double.IsInfinity(v))return false;
 if(Math.Abs(v)<1e-9){if(Math.Abs(p)>half)return false;continue;}double lo=(-half-p)/v,hi=(half-p)/v;if(lo>hi){double t=lo;lo=hi;hi=t;}enter=Math.Max(enter,lo);exit=Math.Min(exit,hi);if(enter>exit)return false;
 }distance=enter;return exit>=0&&enter<=maximum;
 }
}
public partial class Reader {
 public bool TriggerEnabled,TriggerProtect;
 public double TriggerX,TriggerY;
 public int TriggerRange=1000;
 public long TriggerActor;
 public string TriggerState="Off";
 class BodyPart {public long Primitive;public V3 Half,Offset;}
 class BodyCache {public DateTime Until;public List<BodyPart> Parts;}
 Dictionary<long,BodyCache> bodyCache=new Dictionary<long,BodyCache>();
 void ResetBodyRay(){bodyCache.Clear();TriggerActor=0;TriggerState="Waiting";}
 List<BodyPart> BodyParts(long model){BodyCache cached;if(bodyCache.TryGetValue(model,out cached)&&DateTime.UtcNow<cached.Until)return cached.Parts;var parts=new List<BodyPart>();foreach(long child in Children(model)){try{if(!SolidPart(Class(child)))continue;WallBox box=ReadWall(child);if(box==null)continue;long primitive=Ptr(child+o["Primitive"]);V3 position=Vector(primitive);float x=box.Center.X-position.X,y=box.Center.Y-position.Y,z=box.Center.Z-position.Z;parts.Add(new BodyPart{Primitive=primitive,Half=box.Half,Offset=new V3(x*box.Rotation[0]+y*box.Rotation[3]+z*box.Rotation[6],x*box.Rotation[1]+y*box.Rotation[4]+z*box.Rotation[7],x*box.Rotation[2]+y*box.Rotation[5]+z*box.Rotation[8])});}catch(IOException){}}
 bodyCache[model]=new BodyCache{Parts=parts,Until=DateTime.UtcNow.AddMilliseconds(500)};return parts;}
 WallBox BodyPose(BodyPart part){
 // Rotation and position are contiguous in the supported client layout.
 var bytes=Read(part.Primitive+0xB0,48);float[] r=new float[9];for(int i=0;i<9;i++){r[i]=BitConverter.ToSingle(bytes,i*4);if(float.IsNaN(r[i])||float.IsInfinity(r[i]))throw new IOException("Invalid body orientation");}
 for(int i=0;i<3;i++){float norm=r[i]*r[i]+r[i+3]*r[i+3]+r[i+6]*r[i+6];if(norm<.9||norm>1.1)throw new IOException("Stale body orientation");}
 float x=BitConverter.ToSingle(bytes,36),y=BitConverter.ToSingle(bytes,40),z=BitConverter.ToSingle(bytes,44);
 if(float.IsNaN(x)||float.IsNaN(y)||float.IsNaN(z)||float.IsInfinity(x)||float.IsInfinity(y)||float.IsInfinity(z))throw new IOException("Invalid body position");
 V3 off=part.Offset;return new WallBox{Half=part.Half,Rotation=r,Center=new V3(x+r[0]*off.X+r[1]*off.Y+r[2]*off.Z,y+r[3]*off.X+r[4]*off.Y+r[5]*off.Z,z+r[6]*off.X+r[7]*off.Y+r[8]*off.Z)};
 }
 void CheckBodyRay(List<Actor> actors,float[] matrix){
 TriggerActor=0;if(!TriggerEnabled){TriggerState="Off";return;}
 if(WallCheckEnabled&&!WallsReady){TriggerState=WallState;return;}
 V3 ray;if(!CrosshairRay.Direction(matrix,TriggerX,TriggerY,viewOrigin,out ray)){TriggerState="Camera ray unavailable";return;}
 var alive=new HashSet<long>();foreach(var actor in actors)alive.Add(actor.Id);foreach(long key in new List<long>(bodyCache.Keys))if(!alive.Contains(key))bodyCache.Remove(key);
 double closest=TriggerRange;Actor nearest=null;
 foreach(var actor in actors){if(!actor.Alive)continue;try{foreach(BodyPart part in BodyParts(actor.Id)){WallBox body=BodyPose(part);double distance;if(CrosshairRay.Entry(body,viewOrigin,ray,closest,out distance)&&distance>0.05){closest=distance;nearest=actor;}}}catch(IOException){bodyCache.Remove(actor.Id);}}
 if(nearest==null){TriggerState="No body part under crosshair";return;}
 if(!TeamRules.Eligible(nearest.Relation,TriggerProtect)){TriggerState="Ally under crosshair";return;}
 if(WallCheckEnabled){foreach(var wall in wallBoxes){double distance;if(CrosshairRay.Entry(wall,viewOrigin,ray,closest,out distance)&&distance<=closest+.001){TriggerState="Wall before body part";return;}}}
 TriggerActor=nearest.Id;TriggerState="Body part clear — autoclicking";
 }
}
}

