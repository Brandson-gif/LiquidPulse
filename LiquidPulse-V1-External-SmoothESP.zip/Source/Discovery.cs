using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Controls;
namespace LiquidPulse {
public partial class Reader {
 public bool DetectNpcs=true,DetectCustom=true;
 public int PlayerCount,NpcCount,CustomCount;
 long workspaceAddress,localModel,cameraModel;DateTime scanAfter=DateTime.MinValue;
 Queue<Tuple<long,int>> scanQueue=new Queue<Tuple<long,int>>();
 HashSet<long> visited=new HashSet<long>(),found=new HashSet<long>();
 Dictionary<long,Cached> rigs=new Dictionary<long,Cached>();
 Dictionary<long,Cached> fastRigs=new Dictionary<long,Cached>();DateTime fastAfter=DateTime.MinValue;
 bool scanLimited;
 void ResetDiscovery(){ResetWalls();teamRefresh=DateTime.MinValue;resolvedTeams.Clear();teamNames.Clear();owners.Clear();workspaceAddress=localModel=cameraModel=0;scanQueue.Clear();rigs.Clear();fastRigs.Clear();found.Clear();visited.Clear();scanAfter=fastAfter=DateTime.MinValue;}
 void FastDiscover(){
 if(!DetectCustom){fastRigs.Clear();return;}if(DateTime.UtcNow<fastAfter)return;fastAfter=DateTime.UtcNow.AddMilliseconds(250);
 var next=new Dictionary<long,Cached>();try{long container=Find(workspaceAddress,"Players",false);if(container==0){fastRigs.Clear();return;}foreach(long group in Children(container)){try{int count=0;foreach(long model in Children(group)){if(count++>=128)break;if(model==localModel||model==cameraModel)continue;try{Cached c;if(!fastRigs.TryGetValue(model,out c)||Ptr(model+0x60)!=c.Parent)c=GeometryRig(model,0,null);if(c!=null)next[model]=c;}catch(IOException){}}}catch(IOException){}}}catch(IOException){}fastRigs=next;
 }
 static bool PartClass(string cls){return cls=="Part"||cls=="MeshPart"||cls=="UnionOperation"||cls=="WedgePart"||cls=="TrussPart";}
 Cached BuildRig(long model,long player,string label){
 long root=0,head=0,torso=0,humanoid=0;int limbs=0;
 foreach(long child in Children(model)){try{string cls=Class(child);if(cls=="Humanoid"){humanoid=child;continue;}if(!PartClass(cls))continue;string n=Name(child).ToLowerInvariant().Replace(" ","");if(n=="humanoidrootpart"||n=="rootpart"||n=="root")root=child;if(n=="head")head=child;if(n=="torso"||n=="uppertorso"||n=="chest")torso=child;if(n.Contains("arm")||n.Contains("leg")||n.Contains("hand")||n.Contains("foot"))limbs++;}catch(IOException){}}
 if(root==0)root=torso;
 if(root==0&&humanoid!=0){try{root=Ptr(model+0x240);}catch(IOException){}}
 if(root==0||head==0)return GeometryRig(model,player,label);
 bool custom=humanoid==0;
 if(custom&&(torso==0||limbs<2))return GeometryRig(model,player,label);
 return new Cached{Character=model,Parent=Ptr(model+0x60),Player=player,Name=label??Name(model),Root=Ptr(root+o["Primitive"]),Head=Ptr(head+o["Primitive"]),Humanoid=humanoid,Custom=custom};
 }
 Cached GeometryRig(long model,long player,string label){
 long parent=Ptr(model+0x60),group=Ptr(parent+0x60);if(Ptr(group+0x60)!=workspaceAddress||Name(group)!="Players")return null;
 long torso=0,head=0,meshTorso=0,meshHead=0;int limbs=0,parts=0,meshed=0;
 foreach(long child in Children(model)){if(!PartClass(Class(child)))continue;parts++;long primitive=Ptr(child+o["Primitive"]);int textures=0;bool face=false,mesh=false;try{foreach(long decoration in Children(child)){string dc=Class(decoration);if(dc=="SpecialMesh")mesh=true;if(dc=="Decal")face=true;if(dc=="Texture")textures++;}}catch(IOException){}if(mesh){meshed++;if(face)meshHead=primitive;if(textures>=2)meshTorso=primitive;}var size=Read(primitive+0x1C4,12);float x=BitConverter.ToSingle(size,0),y=BitConverter.ToSingle(size,4),z=BitConverter.ToSingle(size,8);
 if(Math.Abs(x-2)<.25&&Math.Abs(y-2)<.25&&Math.Abs(z-1)<.25)torso=primitive;
 else if(Math.Abs(x-2)<.25&&Math.Abs(y-1)<.25&&Math.Abs(z-1)<.25)head=primitive;
 else if(Math.Abs(x-1)<.25&&Math.Abs(y-2)<.25&&Math.Abs(z-1)<.25)limbs++;
 }
 if(parts==6&&meshed==6&&meshHead!=0&&meshTorso!=0&&meshHead!=meshTorso){head=meshHead;torso=meshTorso;}else if(parts!=6||limbs!=4||torso==0||head==0)return null;
 return new Cached{Character=model,Parent=parent,Player=player,Name=label??"Custom rig",Root=torso,Head=head,Custom=true};
 }
 Actor RigSample(Cached c){if(Ptr(c.Character+0x60)!=c.Parent)throw new IOException("Model removed or moved");V3 pos=Vector(c.Root),head=Vector(c.Head);float hp=c.Humanoid==0?1:BitConverter.ToSingle(Read(c.Humanoid+0x184,4),0);bool alive=hp>0&&!float.IsNaN(hp)&&!float.IsInfinity(hp);return new Actor{Id=c.Character,Name=c.Name,Position=pos,Head=head,Alive=alive,Team=c.Player==0?0:Ptr(c.Player+0x2E0),Kind=c.Player!=0?0:(c.Custom?2:1)};}
 void Discover(){
 if(!DetectNpcs&&!DetectCustom){rigs.Clear();scanQueue.Clear();return;}
 if(scanQueue.Count==0){if(DateTime.UtcNow<scanAfter||workspaceAddress==0)return;found.Clear();visited.Clear();scanLimited=false;scanQueue.Enqueue(Tuple.Create(workspaceAddress,0));}
 var budget=Stopwatch.StartNew();int processed=0;
 while(scanQueue.Count>0&&processed++<24&&budget.Elapsed.TotalMilliseconds<1.5){
 var item=scanQueue.Dequeue();if(!visited.Add(item.Item1))continue;if(visited.Count>30000){scanLimited=true;scanQueue.Clear();break;}
 try{
 if(item.Item1==localModel||item.Item1==cameraModel)continue;
 string cls=Class(item.Item1);if(cls=="Model"){Cached rig=BuildRig(item.Item1,0,null);if(rig!=null){found.Add(item.Item1);rigs[item.Item1]=rig;continue;}}
 if(item.Item2>=16)continue;
 if(cls=="Workspace"||cls=="Folder"||cls=="Model"){foreach(long child in Children(item.Item1)){if(scanQueue.Count>=30000){scanLimited=true;break;}string cc;try{cc=Class(child);}catch(IOException){continue;}if(cc=="Model"||cc=="Folder")scanQueue.Enqueue(Tuple.Create(child,item.Item2+1));}}
 }catch(IOException){}
 }
 if(scanQueue.Count==0){foreach(long id in new List<long>(rigs.Keys))if(!found.Contains(id))rigs.Remove(id);scanAfter=DateTime.UtcNow.AddSeconds(1);}
 }
 V3 CameraOrigin(){long camera=Ptr(workspaceAddress+0x4A0);var b=Read(camera+0xE4,12);var v=new V3(BitConverter.ToSingle(b,0),BitConverter.ToSingle(b,4),BitConverter.ToSingle(b,8));if(float.IsNaN(v.X)||float.IsInfinity(v.X)||float.IsNaN(v.Y)||float.IsInfinity(v.Y)||float.IsNaN(v.Z)||float.IsInfinity(v.Z))throw new IOException("Camera unavailable");cameraModel=0;try{long subject=Ptr(camera+0xB0);if(subject!=0){string cls=Class(subject);cameraModel=cls=="Model"?subject:Ptr(subject+0x60);}}catch(IOException){}return v;}
}
public partial class AppWindow {
 TextBlock homeState;
 bool connecting; void ConnectSession(){if(connecting)return;StopTrigger();generation++;int token=generation;actors.Clear();surface.Clear();sampled=DateTime.MinValue;retry=DateTime.MinValue;connected=false;connecting=true;reader.Status="Checking client version and connecting…";Build();System.Threading.Tasks.Task.Run(()=>{bool ok=reader.Connect();if(closing)return;Dispatcher.BeginInvoke(new Action(()=>{connecting=false;if(token!=generation||closing)return;connected=ok;if(ok){s.Enabled=true;nextRead=DateTime.MinValue;nextStatus=DateTime.MinValue;}Build();}));});}
 void DisconnectSession(){StopTrigger();generation++;connected=false;reader.Dispose();reader.Status="Disconnected";actors.Clear();surface.Clear();lockedTarget=0;Build();}
 void HomePage(){var session=Card("Connection",content);session.Children.Add(Text("LiquidPulse V1-External",23));session.Children.Add(Text("Join a game and connect to start ESP. Aimbot and triggerbot have separate toggles.",12,true));var buttons=new StackPanel{Orientation=Orientation.Horizontal,Margin=new Thickness(0,16,0,14)};
 var connect=Button("Connect",ConnectSession);connect.IsEnabled=!connected&&!connecting;buttons.Children.Add(connect);
 var disconnect=Button("Disconnect",DisconnectSession);disconnect.IsEnabled=connected;buttons.Children.Add(disconnect);
 var reconnect=Button("Reconnect",ConnectSession);reconnect.IsEnabled=!connecting;buttons.Children.Add(reconnect);session.Children.Add(buttons);
 homeState=Text(reader.Status,12,true);session.Children.Add(homeState);
 var cols=Columns();var detection=Card("Detection",cols);Toggle(detection,"NPC / Humanoid models",s.DetectNpcs,v=>s.DetectNpcs=v);Toggle(detection,"Custom character rigs",s.DetectCustom,v=>s.DetectCustom=v);detection.Children.Add(Text("Scans nested Workspace models. Unrecognized custom rigs can require a game-specific adapter.",11,true));
 var quick=Card("Quick start",cols);quick.Children.Add(Text("120 FPS target by default.\n"+KeyName(s.EspKey)+"  toggles ESP\n"+KeyName(s.AimKey)+"  toggles aimbot\nHold "+KeyName(s.HoldKey)+" to aim",13,true));quick.Children.Add(Button("Open ESP",()=>{tab="ESP";Build();}));
 }
}
}





