using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
namespace LiquidPulse {
public sealed class WallBox {
 public long Part;public bool Dynamic;public V3 Center,Half;public float[] Rotation;
 public bool Intersects(V3 start,V3 end){
 double ax=start.X-Center.X,ay=start.Y-Center.Y,az=start.Z-Center.Z,dx=end.X-start.X,dy=end.Y-start.Y,dz=end.Z-start.Z;double len=dx*dx+dy*dy+dz*dz;double tClosest=len<1e-12?0:Math.Max(0,Math.Min(1,-(ax*dx+ay*dy+az*dz)/len));double qx=ax+tClosest*dx,qy=ay+tClosest*dy,qz=az+tClosest*dz;if(qx*qx+qy*qy+qz*qz>(double)Half.X*Half.X+(double)Half.Y*Half.Y+(double)Half.Z*Half.Z)return false;double enter=0,exit=0.999;
 for(int axis=0;axis<3;axis++){double p=ax*Rotation[axis]+ay*Rotation[3+axis]+az*Rotation[6+axis],v=dx*Rotation[axis]+dy*Rotation[3+axis]+dz*Rotation[6+axis],half=axis==0?Half.X:axis==1?Half.Y:Half.Z;
 if(double.IsNaN(p)||double.IsNaN(v)||double.IsInfinity(p)||double.IsInfinity(v))return true;
 if(Math.Abs(v)<1e-8){if(Math.Abs(p)>half)return false;continue;}
 double lo=(-half-p)/v,hi=(half-p)/v;if(lo>hi){double t=lo;lo=hi;hi=t;}enter=Math.Max(enter,lo);exit=Math.Min(exit,hi);if(enter>exit)return false;
 }return exit>=0&&enter<.999;
 }
}
public partial class Reader {
 public bool WallCheckEnabled;public bool WallsReady;
 public string WallState="Off";public string WallLastError="";
 V3 viewOrigin;
 Queue<long> wallQueue=new Queue<long>();
 HashSet<long> wallVisited=new HashSet<long>();
 List<WallBox> wallBuilding=new List<WallBox>(),wallBoxes=new List<WallBox>();
 DateTime wallPublished=DateTime.MinValue,wallNext=DateTime.MinValue;
 bool wallFault;
 void ResetWalls(){ResetBodyRay();WallsReady=false;wallQueue.Clear();wallVisited.Clear();wallBuilding.Clear();wallBoxes.Clear();wallPublished=wallNext=DateTime.MinValue;wallFault=false;WallState="Waiting";}
 static bool SolidPart(string type){return PartClass(type)||type=="CornerWedgePart";}
 V3 ReadV3(long address){byte[] b=Read(address,12);var v=new V3(BitConverter.ToSingle(b,0),BitConverter.ToSingle(b,4),BitConverter.ToSingle(b,8));if(float.IsNaN(v.X)||float.IsNaN(v.Y)||float.IsNaN(v.Z)||float.IsInfinity(v.X)||float.IsInfinity(v.Y)||float.IsInfinity(v.Z))throw new IOException("Invalid geometry");return v;}
 WallBox ReadWall(long part){
 float transparency=BitConverter.ToSingle(Read(part+0x118,4),0);
 if(float.IsNaN(transparency)||transparency<0||transparency>1)throw new IOException("Invalid transparency");
 if(transparency>=.95)return null;
 long primitive=Ptr(part+o["Primitive"]);V3 center=ReadV3(primitive+o["Position"]),size=ReadV3(primitive+0x1C4);
 if(size.X<=0||size.Y<=0||size.Z<=0||size.X>100000||size.Y>100000||size.Z>100000)throw new IOException("Invalid bounds");
 float[] rotation=new float[9];var bytes=Read(primitive+0xB0,36);for(int i=0;i<9;i++){rotation[i]=BitConverter.ToSingle(bytes,i*4);if(float.IsNaN(rotation[i])||float.IsInfinity(rotation[i]))throw new IOException("Invalid orientation");}
 for(int axis=0;axis<3;axis++){float length=rotation[axis]*rotation[axis]+rotation[axis+3]*rotation[axis+3]+rotation[axis+6]*rotation[axis+6];if(length<.9||length>1.1)throw new IOException("Invalid orientation");}
 // Legacy meshes can extend beyond their parent Part.Size.
 try{foreach(long child in Children(part)){string cls=Class(child);if(cls!="SpecialMesh"&&cls!="BlockMesh"&&cls!="CylinderMesh")continue;V3 scale=ReadV3(child+0xAC),offset=ReadV3(child+0xA0);size=new V3(size.X*Math.Max(1,Math.Abs(scale.X)),size.Y*Math.Max(1,Math.Abs(scale.Y)),size.Z*Math.Max(1,Math.Abs(scale.Z)));center=new V3(center.X+rotation[0]*offset.X+rotation[1]*offset.Y+rotation[2]*offset.Z,center.Y+rotation[3]*offset.X+rotation[4]*offset.Y+rotation[5]*offset.Z,center.Z+rotation[6]*offset.X+rotation[7]*offset.Y+rotation[8]*offset.Z);break;}}catch(IOException){}
 return new WallBox{Part=part,Dynamic=(Read(primitive+0x1BE,1)[0]&2)==0,Center=center,Half=new V3(size.X*.5f,size.Y*.5f,size.Z*.5f),Rotation=rotation};
 }
 void UpdateWalls(List<Actor> actors){
 if(!WallCheckEnabled){WallsReady=true;WallState="Off";return;}
 var excluded=new HashSet<long>();excluded.Add(localModel);excluded.Add(cameraModel);foreach(var a in actors)excluded.Add(a.Id);foreach(var c in cache.Values)excluded.Add(c.Character);foreach(long c in rigs.Keys)excluded.Add(c);foreach(long c in fastRigs.Keys)excluded.Add(c);
 if(wallQueue.Count==0&&DateTime.UtcNow>=wallNext){wallVisited.Clear();wallBuilding=new List<WallBox>();wallFault=false;long scanRoot=workspaceAddress;try{long map=Find(workspaceAddress,"Map",false);if(map!=0&&Find(workspaceAddress,"Roots",false)!=0&&Find(workspaceAddress,"Players",false)!=0)scanRoot=map;}catch(IOException){}wallQueue.Enqueue(scanRoot);}
 var budget=Stopwatch.StartNew();int nodes=0;
 while(wallQueue.Count>0&&budget.Elapsed.TotalMilliseconds<2&&nodes++<96){
 long node=wallQueue.Dequeue();if(!wallVisited.Add(node)||excluded.Contains(node))continue;
 if(wallVisited.Count>40000){wallFault=true;wallQueue.Clear();break;}
 try{string cls=Class(node);if(cls=="Camera"||cls=="Tool"||cls=="Accessory")continue;
 if(SolidPart(cls)){WallBox box=ReadWall(node);if(box!=null)wallBuilding.Add(box);}
 if(cls=="Workspace"||cls=="Folder"||cls=="Model"||SolidPart(cls)){foreach(long child in Children(node)){if(wallQueue.Count>=40000){wallFault=true;break;}wallQueue.Enqueue(child);}}
 }catch(IOException e){wallFault=true;WallLastError=e.Message;}
 }
 if(wallQueue.Count==0&&wallNext<=DateTime.UtcNow){
 if(!wallFault){wallBoxes=wallBuilding;wallPublished=DateTime.UtcNow;}
 wallNext=DateTime.UtcNow.AddMilliseconds(250);
 }
 bool ready=DateTime.UtcNow-wallPublished<TimeSpan.FromSeconds(2);if(ready){for(int i=0;i<wallBoxes.Count;i++){if(!wallBoxes[i].Dynamic)continue;try{WallBox current=ReadWall(wallBoxes[i].Part);if(current==null){ready=false;break;}wallBoxes[i]=current;}catch(IOException e){ready=false;WallLastError=e.Message;break;}}}
 WallState=ready?"Checking "+wallBoxes.Count+" part bounds":wallFault?"Geometry unavailable — firing paused":"Scanning geometry — firing paused";
 WallsReady=ready;
 }
 bool Visible(V3 start,V3 end){foreach(var box in wallBoxes)if(box.Intersects(start,end))return false;return true;}
}
}






