using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace LiquidPulse {
public partial class Reader {
 class Cached {public long Player,Character,Root,Head,Humanoid,Parent;public string Name;public bool Custom;}
 Dictionary<long,Cached> cache=new Dictionary<long,Cached>();
 List<long> roster=new List<long>();long localAddress,playersAddress;DateTime discovery=DateTime.MinValue;
 public long LocalTeam;
 void ResetCache(){ResetDiscovery();cache.Clear();roster.Clear();discovery=DateTime.MinValue;playersAddress=localAddress=0;}
 public bool Connect(){lock(this){return ConnectCore();}}
 public void Dispose(){lock(this){ResetCache();DisposeCore();}}
 V3 Vector(long primitive){var b=Read(primitive+o["Position"],12);var v=new V3(BitConverter.ToSingle(b,0),BitConverter.ToSingle(b,4),BitConverter.ToSingle(b,8));if(float.IsNaN(v.X)||float.IsInfinity(v.X)||float.IsNaN(v.Y)||float.IsInfinity(v.Y)||float.IsNaN(v.Z)||float.IsInfinity(v.Z))throw new IOException("Invalid position");return v;}
 Actor Sample(long address){long model=Ptr(address+o["ModelInstance"]);if(model==0){cache.Remove(address);throw new IOException("Character has not spawned");}Cached c;if(!cache.TryGetValue(address,out c)||c.Character!=model){c=BuildRig(model,address,Name(address));if(c==null)throw new IOException("Custom character not yet recognized");cache[address]=c;}try{return RigSample(c);}catch{cache.Remove(address);throw;}}
 public bool Snapshot(out List<Actor> actors,out float[] matrix,out V3 origin){lock(this){actors=new List<Actor>();matrix=new float[16];origin=new V3();if(handle==IntPtr.Zero)return false;try{
 if(process.HasExited){Status="Roblox closed";Dispose();return false;}
 if(DateTime.UtcNow>=discovery){long dm=Ptr(Ptr(baseAddress+o["FakeDataModelPointer"])+o["FakeDataModelToDataModel"]);long ws=Find(dm,"Workspace",true);if(ws!=workspaceAddress){ResetDiscovery();workspaceAddress=ws;}playersAddress=Find(dm,"Players",true);localAddress=Ptr(playersAddress+o["LocalPlayer"]);roster=Children(playersAddress);var keep=new HashSet<long>(roster);foreach(long id in new List<long>(cache.Keys))if(!keep.Contains(id))cache.Remove(id);discovery=DateTime.UtcNow.AddMilliseconds(500);}
 origin=CameraOrigin();viewOrigin=origin;LocalTeam=0;localModel=0;
 try{localModel=Ptr(localAddress+o["ModelInstance"]);LocalTeam=Ptr(localAddress+0x2E0);origin=Sample(localAddress).Position;}catch(IOException){}
 var bytes=Read(Ptr(baseAddress+o["VisualEnginePointer"])+o["ViewMatrix"],64);bool nonzero=false;for(int i=0;i<16;i++){matrix[i]=BitConverter.ToSingle(bytes,i*4);if(float.IsNaN(matrix[i])||float.IsInfinity(matrix[i]))throw new IOException("Invalid view matrix");nonzero|=matrix[i]!=0;}if(!nonzero)throw new IOException("Empty view matrix");
 PlayerCount=NpcCount=CustomCount=0;var seen=new HashSet<long>();seen.Add(localModel);seen.Add(cameraModel);
 foreach(long id in roster){if(id==localAddress)continue;try{var a=Sample(id);if(a.Alive&&seen.Add(a.Id)){actors.Add(a);PlayerCount++;}}catch(IOException){}}
 FastDiscover();Discover();
 var allRigs=new Dictionary<long,Cached>(rigs);foreach(var fast in fastRigs)allRigs[fast.Key]=fast.Value;foreach(var pair in allRigs){if(seen.Contains(pair.Key))continue;var c=pair.Value;if(c.Custom?!DetectCustom:!DetectNpcs)continue;try{var a=RigSample(c);if(!a.Alive)continue;if(seen.Add(a.Id)){actors.Add(a);if(c.Custom)CustomCount++;else NpcCount++;}}catch(IOException){}}
 UpdateWalls(actors);ClassifyTeams(actors);CheckBodyRay(actors,matrix);Status="Connected / "+PlayerCount+" players / "+NpcCount+" NPC rigs / "+CustomCount+" custom / teams "+FriendlyCount+" ally, "+EnemyCount+" enemy, "+UnknownCount+" unknown"+(scanQueue.Count>0?" / scanning":scanLimited?" / scan limit":"");return true;
 }catch(Exception e){Status="Waiting: "+e.Message;ResetCache();return false;}}}

}
public class RenderActor {public bool ColorTeams;public Relation Relation;public double X,Y,H;public string Name;public bool Custom;}
public class FastSurface:FrameworkElement {
 readonly Brush accent=new SolidColorBrush(Color.FromRgb(139,206,255));readonly Brush back=new SolidColorBrush(Color.FromArgb(180,18,30,50));readonly Pen pen;readonly Pen allyPen=new Pen(new SolidColorBrush(Color.FromRgb(100,230,174)),1.4),enemyPen=new Pen(new SolidColorBrush(Color.FromRgb(255,100,119)),1.4),unknownPen=new Pen(new SolidColorBrush(Color.FromRgb(255,195,100)),1.4);readonly Typeface font=new Typeface("Segoe UI");
 Dictionary<string,FormattedText> labels=new Dictionary<string,FormattedText>();
 public List<RenderActor> Actors=new List<RenderActor>();public bool Names,Boxes,Lines,Ring;public Point RingCenter;public double Radius;
 public FastSurface(){accent.Freeze();back.Freeze();pen=new Pen(accent,1.4);pen.Freeze();allyPen.Freeze();enemyPen.Freeze();unknownPen.Freeze();}
 public void Clear(){Actors.Clear();Ring=false;InvalidateVisual();}
 public void Present(List<RenderActor> a,bool names,bool boxes,bool lines){Actors=a;Names=names;Boxes=boxes;Lines=lines;if(labels.Count>512)labels.Clear();InvalidateVisual();}
 protected override void OnRender(DrawingContext d){base.OnRender(d);if(Ring)d.DrawEllipse(null,pen,RingCenter,Radius,Radius);foreach(var a in Actors){Pen actorPen=!a.ColorTeams?pen:a.Relation==Relation.Friendly?allyPen:a.Relation==Relation.Enemy?enemyPen:unknownPen;double w=a.H*.52;if(Boxes)d.DrawRoundedRectangle(null,actorPen,new Rect(a.X-w/2,a.Y-a.H,w,a.H),3,3);if(Lines)d.DrawLine(actorPen,new Point(ActualWidth/2,ActualHeight),new Point(a.X,a.Y));if(Names){FormattedText t;string labelKey=a.Name+"|"+a.Relation+"|"+a.ColorTeams;if(!labels.TryGetValue(labelKey,out t)){t=new FormattedText(a.Name,CultureInfo.InvariantCulture,FlowDirection.LeftToRight,font,12,actorPen.Brush,VisualTreeHelper.GetDpi(this).PixelsPerDip);labels[labelKey]=t;}var point=new Point(a.X-t.Width/2,a.Y-a.H-25);d.DrawRoundedRectangle(back,null,new Rect(point.X-5,point.Y-2,t.Width+10,t.Height+4),3,3);d.DrawText(t,point);}}}
}
public class AimCandidate {public long Id;public Point Point;}
public class AimMotion {
 double vx,vy,carryX,carryY;
 public void Reset(){vx=vy=carryX=carryY=0;}
 public Vector Next(Point target,Point origin,double dt,int smooth,int gain){
 dt=Math.Max(.001,Math.Min(.05,dt));double ex=target.X-origin.X,ey=target.Y-origin.Y;
 if(ex*ex+ey*ey<2.25){Reset();return new Vector();}
 double rate=(1-Math.Exp(-dt*60/Math.Max(1,smooth)))/dt*gain/100.0;
 double blend=1-Math.Exp(-dt/.035);vx+=(ex*rate-vx)*blend;vy+=(ey*rate-vy)*blend;
 double speed=Math.Sqrt(vx*vx+vy*vy);if(speed>1200){vx*=1200/speed;vy*=1200/speed;}
 double x=vx*dt+carryX,y=vy*dt+carryY;
 if(x*ex<0)x=0;if(y*ey<0)y=0;
 if(Math.Abs(x)>Math.Abs(ex))x=ex;if(Math.Abs(y)>Math.Abs(ey))y=ey;
 int mx=(int)Math.Round(x),my=(int)Math.Round(y);carryX=x-mx;carryY=y-my;return new Vector(mx,my);
 }
}
public static class AimLogic {
 public static long Select(List<AimCandidate> candidates,Point origin,double radius,long locked,out Point target){target=new Point();long id=0;double best=radius*radius;foreach(var c in candidates){double x=c.Point.X-origin.X,y=c.Point.Y-origin.Y,d=x*x+y*y;if(double.IsNaN(d)||double.IsInfinity(d)||d>radius*radius)continue;if(c.Id==locked){target=c.Point;return c.Id;}if(d<=best){best=d;target=c.Point;id=c.Id;}}return id;}
 public static Vector Step(Point target,Point origin,double dt,int smooth,int gain,ref double carryX,ref double carryY){double factor=(1-Math.Exp(-Math.Min(.05,Math.Max(.001,dt))*60/Math.Max(1,smooth)))*gain/100.0;double x=(target.X-origin.X)*factor+carryX,y=(target.Y-origin.Y)*factor+carryY;int mx=(int)Math.Max(-80,Math.Min(80,Math.Round(x))),my=(int)Math.Max(-80,Math.Min(80,Math.Round(y)));carryX=x-Math.Round(x);carryY=y-Math.Round(y);return new Vector(mx,my);}
}
public partial class AppWindow {
 [DllImport("user32.dll")] static extern short GetAsyncKeyState(int key);
 [DllImport("user32.dll")] static extern bool GetCursorPos(out POINT p);
 [DllImport("user32.dll",SetLastError=true)] static extern uint SendInput(uint count,INPUT[] input,int size);
 [StructLayout(LayoutKind.Sequential)] struct MOUSEINPUT{public int dx,dy;public uint data,flags,time;public UIntPtr extra;}
 [StructLayout(LayoutKind.Sequential)] struct INPUT{public uint type;public MOUSEINPUT mouse;}
 IntPtr gameWindow; bool busy;volatile bool closing;int generation;DateTime sampled=DateTime.MinValue,retry=DateTime.MinValue,lastFrame=DateTime.UtcNow;long localTeam,lockedTarget;string capture;Button captureButton;DateTime captureAfter;bool[] keyStates=new bool[256];AimMotion aimMotion=new AimMotion();readonly Stopwatch readWatch=new Stopwatch();double readMs;
 static bool Down(int key){return (GetAsyncKeyState(key)&0x8000)!=0;}
 string KeyName(int key){switch(key){case 164:return "Left Alt";case 1:return "Mouse Left";case 2:return "Mouse Right";case 4:return "Mouse Middle";case 5:return "Mouse X1";case 6:return "Mouse X2";default:return KeyInterop.KeyFromVirtualKey(key).ToString();}}
 void BindRow(Panel panel,string label,string id,int key){var row=new DockPanel{Margin=new Thickness(0,3,0,5)};Button b=null;b=Button(KeyName(key),()=>{capture=id;captureButton=b;b.Content="Press key / mouse…";captureAfter=DateTime.UtcNow.AddMilliseconds(200);for(int i=0;i<256;i++)keyStates[i]=Down(i);});b.MinWidth=145;DockPanel.SetDock(b,Dock.Right);row.Children.Add(b);row.Children.Add(Text(label,12));panel.Children.Add(row);}
 bool SetBinding(string id,int key){int[] keys={s.MenuKey,s.EspKey,s.AimKey,s.HoldKey,s.TriggerKey};string[] ids={"menu","esp","aim","hold","trigger"};for(int i=0;i<5;i++)if(ids[i]!=id&&keys[i]==key){status.Text="That key is already assigned";return false;}if(id=="menu")s.MenuKey=key;if(id=="esp")s.EspKey=key;if(id=="aim")s.AimKey=key;if(id=="hold")s.HoldKey=key;if(id=="trigger")s.TriggerKey=key;s.Save();return true;}
 void PollKeys(){bool[] now=new bool[256];int[] keys=capture==null?new[]{s.MenuKey,s.EspKey,s.AimKey,s.HoldKey,s.TriggerKey}:System.Linq.Enumerable.ToArray(System.Linq.Enumerable.Range(1,254));foreach(int k in keys)now[k]=Down(k);
 if(capture!=null){if(!IsActive){capture=null;Build();}else if(DateTime.UtcNow>=captureAfter){foreach(int k in keys){if(!now[k]||keyStates[k])continue;if(k==27){capture=null;Build();break;}if(k==1&&captureButton!=null&&captureButton.IsMouseOver)continue;if(SetBinding(capture,k)){capture=null;Build();}break;}}}
 else {if(now[s.MenuKey]&&!keyStates[s.MenuKey]){if(IsVisible&&WindowState!=WindowState.Minimized)Hide();else{Show();WindowState=WindowState.Normal;Activate();}}if(now[s.EspKey]&&!keyStates[s.EspKey]){s.Enabled=!s.Enabled;Build();}if(now[s.AimKey]&&!keyStates[s.AimKey]){s.Aim=!s.Aim;lockedTarget=0;Build();}if(now[s.TriggerKey]&&!keyStates[s.TriggerKey]){s.Trigger=!s.Trigger;StopTrigger();Build();}}
 keyStates=now;}
 void AimPage(){var cols=Columns();var gen=Card("General",cols);Toggle(gen,"Aimbot",s.Aim,v=>s.Aim=v);Toggle(gen,"Show aim radius",s.ShowFov,v=>s.ShowFov=v);gen.Children.Add(Text("Hold "+KeyName(s.HoldKey)+" to aim. Rebind in Settings.",11,true));var targets=Card("Targets",cols);targets.Children.Add(Button(s.TeamCheck?"Teams: Exclude known allies":"Teams: All teams",()=>{s.TeamCheck=!s.TeamCheck;lockedTarget=0;aimMotion.Reset();s.Save();Build();}));targets.Children.Add(Button(s.AimHead?"Target: Head":"Target: Torso",()=>{s.AimHead=!s.AimHead;Build();}));targets.Children.Add(Button(s.CursorAim?"Origin: Mouse cursor":"Origin: Screen center",()=>{s.CursorAim=!s.CursorAim;Build();}));var tuning=Card("Tuning",content);Slide(tuning,"Aim radius (px)",30,500,s.Fov,v=>s.Fov=v);Slide(tuning,"Smoothness",1,20,s.Smooth,v=>s.Smooth=v);Slide(tuning,"Mouse gain (%)",5,100,s.Gain,v=>s.Gain=v);tuning.Children.Add(Text("Screen center: first-person / shift-lock. No line-of-sight filtering.",11,true));foreach(UIElement item in tuning.Children){var label=item as TextBlock;if(label!=null&&label.Margin.Top>0)label.Margin=new Thickness(0,3,0,3);}}
 void SettingsPage(){var card=Card("Interface",content);Toggle(card,"Dark Mode",s.Dark,v=>{s.Dark=v;s.Save();Build();});var keys=Card("Keybinds • click to change / Esc cancels",content);BindRow(keys,"Menu","menu",s.MenuKey);BindRow(keys,"ESP toggle","esp",s.EspKey);BindRow(keys,"Aimbot toggle","aim",s.AimKey);BindRow(keys,"Aimbot hold","hold",s.HoldKey);BindRow(keys,"Triggerbot toggle","trigger",s.TriggerKey);keys.Children.Add(Text("Keyboard / mouse buttons supported. Changes save automatically.",11,true));}
 DateTime nextRead=DateTime.MinValue,nextStatus=DateTime.MinValue; long bodyRayActor; void ReadFrame(){DateTime requestTime=DateTime.UtcNow;if(busy||requestTime<retry||requestTime<nextRead)return;double period=1.0/s.Hz;nextRead=(requestTime-nextRead).TotalSeconds>period?requestTime.AddSeconds(period):nextRead.AddSeconds(period);busy=true;int token=generation;bool npcs=s.DetectNpcs,custom=s.DetectCustom,walls=s.Trigger&&s.TriggerWall,trigger=s.Trigger,protect=s.TriggerTeam;int range=s.Distance;double nx=0,ny=0;RECT viewport;POINT screenOrigin=new POINT(),cursor;if(s.CursorAim&&gameWindow!=IntPtr.Zero&&GetClientRect(gameWindow,out viewport)&&viewport.R>0&&viewport.B>0&&ClientToScreen(gameWindow,ref screenOrigin)&&GetCursorPos(out cursor)){nx=2.0*(cursor.X-screenOrigin.X)/viewport.R-1;ny=1-2.0*(cursor.Y-screenOrigin.Y)/viewport.B;}Task.Run(()=>{List<Actor> a;float[] m;V3 o;long team,triggerActor;IntPtr window;string state,wallState;readWatch.Restart();bool ok;lock(reader){reader.TriggerEnabled=trigger;reader.TriggerProtect=protect;reader.TriggerRange=range;reader.TriggerX=nx;reader.TriggerY=ny;reader.WallCheckEnabled=walls;reader.DetectNpcs=npcs;reader.DetectCustom=custom;ok=reader.Snapshot(out a,out m,out o);team=reader.LocalTeam;state=reader.Status;wallState=reader.TriggerState;triggerActor=reader.TriggerActor;window=reader.WindowHandle;}double elapsed=readWatch.Elapsed.TotalMilliseconds;DateTime at=DateTime.UtcNow.AddMilliseconds(-elapsed);if(closing)return;Dispatcher.BeginInvoke(new Action(()=>{busy=false;if(token!=generation||closing)return;actors=ok?a:new List<Actor>();bodyRayActor=ok&&trigger==s.Trigger&&walls==(s.Trigger&&s.TriggerWall)&&protect==s.TriggerTeam?triggerActor:0;matrix=m;origin=o;localTeam=team;gameWindow=window;sampled=at;readMs=elapsed;if(!ok||DateTime.UtcNow>=nextStatus){nextStatus=DateTime.UtcNow.AddMilliseconds(250);status.Text=state+(ok?" / "+elapsed.ToString("0.0")+" ms":"")+" / ESP "+(s.Enabled?"ON":"OFF")+" ("+KeyName(s.EspKey)+")";if(homeState!=null)homeState.Text=status.Text;if(wallLabel!=null)wallLabel.Text=wallState;}if(!ok)retry=DateTime.UtcNow.AddMilliseconds(300);if(s.Trigger)FireTrigger(bodyRayActor);}));});}
 void Tick(object sender,EventArgs e){PollKeys();DateTime now=DateTime.UtcNow;double dt=Math.Min(.05,Math.Max(.001,(now-lastFrame).TotalSeconds));lastFrame=now;if(!connected){surface.Clear();StopTrigger();return;}ReadFrame();IntPtr hwnd=gameWindow;if(hwnd==IntPtr.Zero||GetForegroundWindow()!=hwnd||now-sampled>TimeSpan.FromMilliseconds(250)){surface.Clear();lockedTarget=0;aimMotion.Reset();StopTrigger();return;}RECT r;POINT p=new POINT();if(!GetClientRect(hwnd,out r)||!ClientToScreen(hwnd,ref p)||r.R<=0||r.B<=0){surface.Clear();StopTrigger();return;}var transform=PresentationSource.FromVisual(overlay).CompositionTarget.TransformFromDevice;Point top=transform.Transform(new Point(p.X,p.Y)),size=transform.Transform(new Point(r.R,r.B));if(overlay.Left!=top.X)overlay.Left=top.X;if(overlay.Top!=top.Y)overlay.Top=top.Y;if(overlay.Width!=size.X)overlay.Width=size.X;if(overlay.Height!=size.Y)overlay.Height=size.Y;if(surface.Width!=size.X)surface.Width=size.X;if(surface.Height!=size.Y)surface.Height=size.Y;
 Point aimOrigin=new Point(r.R/2.0,r.B/2.0);POINT mouse;if(s.CursorAim&&GetCursorPos(out mouse))aimOrigin=new Point(mouse.X-p.X,mouse.Y-p.Y);bool holding=s.Aim&&capture==null&&Down(s.HoldKey);if(!holding){lockedTarget=0;aimMotion.Reset();}Point target=new Point();long targetId=0;var candidates=new List<AimCandidate>();var draw=new List<RenderActor>();long triggerTarget=bodyRayActor;
 foreach(var a in actors){double dx=a.Position.X-origin.X,dy=a.Position.Y-origin.Y,dz=a.Position.Z-origin.Z;if(dx*dx+dy*dy+dz*dz>(double)s.Distance*s.Distance)continue;Point center,head,foot;if(s.Enabled&&(!s.HideAllies||a.Relation!=Relation.Friendly)&&Project(a.Position,size.X,size.Y,out center)&&Project(new V3(a.Head.X,a.Head.Y+1,a.Head.Z),size.X,size.Y,out head)&&Project(new V3(a.Position.X,a.Position.Y-3,a.Position.Z),size.X,size.Y,out foot)){double height=Math.Abs(foot.Y-head.Y);if(height>=2&&height<=size.Y*2&&center.X>=0&&center.X<=size.X&&center.Y>=0&&center.Y<=size.Y)draw.Add(new RenderActor{X=center.X,Y=Math.Max(head.Y,foot.Y),H=height,Name=a.Name+(s.ShowTeams?" ["+a.Relation+"]":""),ColorTeams=s.ShowTeams,Relation=a.Relation});}
 Point projected;if(holding&&a.Alive&&TeamRules.Eligible(a.Relation,s.TeamCheck)&&Project(s.AimHead?a.Head:a.Position,r.R,r.B,out projected)&&projected.X>=0&&projected.X<=r.R&&projected.Y>=0&&projected.Y<=r.B){candidates.Add(new AimCandidate{Id=a.Id,Point=projected});}}
 FireTrigger(now-sampled>TimeSpan.FromMilliseconds(Math.Min(150,Math.Max(50,1800.0/s.Hz)))?0:triggerTarget);targetId=AimLogic.Select(candidates,aimOrigin,s.Fov,lockedTarget,out target);surface.Ring=s.Aim&&s.ShowFov;surface.RingCenter=transform.Transform(aimOrigin);surface.Radius=s.Fov*transform.M11;surface.Present(draw,s.Names,s.Boxes,s.Lines);
 if(holding&&targetId!=0){if(lockedTarget!=targetId)aimMotion.Reset();lockedTarget=targetId;Vector movement=aimMotion.Next(target,aimOrigin,dt,s.Smooth,s.Gain);int mx=(int)movement.X,my=(int)movement.Y;if(mx!=0||my!=0){var input=new[]{new INPUT{type=0,mouse=new MOUSEINPUT{dx=mx,dy=my,flags=1}}};if(SendInput(1,input,Marshal.SizeOf(typeof(INPUT)))!=1){s.Aim=false;status.Text="Mouse input was blocked; aimbot disabled";}}}else {lockedTarget=0;aimMotion.Reset();}
 }
}
}

















