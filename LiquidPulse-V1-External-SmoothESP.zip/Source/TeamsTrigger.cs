using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Controls;
namespace LiquidPulse {
public enum Relation { Unknown, Friendly, Enemy }
public partial class Reader {
 Dictionary<long,long> owners=new Dictionary<long,long>();
 Dictionary<long,string> teamNames=new Dictionary<long,string>();
 Dictionary<long,long> resolvedTeams=new Dictionary<long,long>();
 DateTime teamRefresh=DateTime.MinValue;
 bool localNeutral=true;
 public int FriendlyCount,EnemyCount,UnknownCount;
 long CheckedPlayerTeam(long player){if(!roster.Contains(player)||Read(player+0x3D4,1)[0]!=0)return 0;long team=Ptr(player+0x2E0);return teamNames.ContainsKey(team)?team:0;}
 void RefreshTeams(){
 if(DateTime.UtcNow<teamRefresh)return;teamRefresh=DateTime.UtcNow.AddMilliseconds(500);owners.Clear();resolvedTeams.Clear();teamNames.Clear();
 try{long dm=Ptr(Ptr(baseAddress+o["FakeDataModelPointer"])+o["FakeDataModelToDataModel"]);long teams=Find(dm,"Teams",true);if(teams!=0)foreach(long t in Children(teams)){try{if(Class(t)=="Team")teamNames[t]=Name(t);}catch(IOException){}}}catch(IOException){}
 foreach(long player in roster){try{long model=Ptr(player+o["ModelInstance"]);if(model!=0)owners[model]=player;}catch(IOException){}}
 try{localNeutral=Read(localAddress+0x3D4,1)[0]!=0;LocalTeam=CheckedPlayerTeam(localAddress);}catch(IOException){localNeutral=true;LocalTeam=0;}
 }
 long TeamForModel(long model){
 long team;if(resolvedTeams.TryGetValue(model,out team))return team;
 long player;if(owners.TryGetValue(model,out player)){try{team=CheckedPlayerTeam(player);resolvedTeams[model]=team;return team;}catch(IOException){}}
 team=0;try{
 var candidates=new List<long>(Children(model));
 foreach(long child in new List<long>(candidates)){try{string n=Name(child);if((n=="Metadata"||n=="Configuration")&&(Class(child)=="Folder"||Class(child)=="Configuration"))candidates.AddRange(Children(child));}catch(IOException){}}
 foreach(long child in candidates){string n=Name(child),cls=Class(child);
 if((n=="Owner"||n=="Player")&&cls=="ObjectValue"){long p=Ptr(child+0xA0);if(roster.Contains(p)){team=CheckedPlayerTeam(p);if(team!=0)break;}}
 if(n=="Team"&&cls=="ObjectValue"){long t=Ptr(child+0xA0);if(teamNames.ContainsKey(t)){team=t;break;}}
 if((n=="TeamColor"||n=="Team")&&cls=="BrickColorValue"){int color=BitConverter.ToInt32(Read(child+0xA0,4),0);var matches=new List<long>();foreach(long t in teamNames.Keys)if(BitConverter.ToInt32(Read(t+0xA0,4),0)==color)matches.Add(t);if(matches.Count==1){team=matches[0];break;}}
 }
 if(team==0){long parent=Ptr(model+0x60),container=Ptr(parent+0x60);string cn=Name(container);if(cn=="Players"||cn=="Characters"||cn=="NPCs"||cn=="Teams"){string group=Name(parent);var matches=teamNames.Where(t=>string.Equals(t.Value,group,StringComparison.OrdinalIgnoreCase)).Select(t=>t.Key).ToList();if(matches.Count==1)team=matches[0];}}
 }catch(IOException){}
 resolvedTeams[model]=team;return team;
 }
 void ClassifyTeams(List<Actor> actors){RefreshTeams();FriendlyCount=EnemyCount=UnknownCount=0;foreach(var a in actors){long team=TeamForModel(a.Id);a.Relation=TeamRules.Classify(LocalTeam,team,localNeutral);if(a.Relation==Relation.Friendly)FriendlyCount++;else if(a.Relation==Relation.Enemy)EnemyCount++;else UnknownCount++;}}
}
public static class TeamRules {
 public static Relation Classify(long local,long target,bool neutral){return neutral||local==0||target==0?Relation.Unknown:local==target?Relation.Friendly:Relation.Enemy;}
 public static bool Eligible(Relation relation,bool protection){return !protection||relation!=Relation.Friendly;}
}
public class TriggerClock {
 long target;double acquired,next;
 public void Reset(){target=0;acquired=next=0;}
 public bool Ready(long id,double now,int cps,int delay){if(id==0){target=0;acquired=0;return false;}if(id!=target){target=id;acquired=now;}if(now-acquired<delay||now<next)return false;next=now+1000.0/Math.Max(1,cps);return true;}
}
public partial class AppWindow {
 System.Windows.Controls.TextBlock wallLabel;
 readonly TriggerClock triggerClock=new TriggerClock();
 readonly System.Diagnostics.Stopwatch triggerTime=System.Diagnostics.Stopwatch.StartNew();
 void TriggerPage(){var cols=Columns();var general=Card("General",cols);Toggle(general,"Triggerbot",s.Trigger,v=>{s.Trigger=v;StopTrigger();});general.Children.Add(Button(s.TriggerTeam?"Teams: Exclude known allies":"Teams: All teams",()=>{s.TriggerTeam=!s.TriggerTeam;StopTrigger();s.Save();Build();}));general.Children.Add(Text("Toggle with "+KeyName(s.TriggerKey)+". Autoclicks while the crosshair is on a target.",12,true));
 var target=Card("Targets",cols);Toggle(target,"Wall check",s.TriggerWall,v=>{s.TriggerWall=v;StopTrigger();s.Save();});target.Children.Add(Text("Hit region: All visible body-part bounds",12,true));target.Children.Add(Text("All teams allows either side. Exclude known allies still allows unknown teams. Roblox must have focus.",12,true));
 var timing=Card("Timing",content);Slide(timing,"Clicks per second",1,40,s.TriggerCps,v=>s.TriggerCps=v);timing.Children.Add(Text("Starts on the first clear body-part hit. No added dwell delay.",12,true));wallLabel=Text(s.TriggerWall?"Wall check warms up when triggerbot is enabled.":"Wall check off",11,true);timing.Children.Add(wallLabel);}
 bool TriggerHit(Actor a,Point cross,double width,double height){Point head,torso,top,bottom;V3 center=a.Head;
 if((!s.TriggerWall||a.HeadVisible)&&Project(center,width,height,out head)&&Project(new V3(center.X,center.Y+0.65f,center.Z),width,height,out top)&&Project(new V3(center.X,center.Y-0.65f,center.Z),width,height,out bottom)){double radius=Math.Abs(bottom.Y-top.Y)*.5;if(radius>=1&&Math.Abs(cross.X-head.X)<=radius*.8&&Math.Abs(cross.Y-head.Y)<=radius)return true;}
 if(s.TriggerHead||(s.TriggerWall&&!a.TorsoVisible))return false;center=a.Position;if(!Project(center,width,height,out torso)||!Project(new V3(center.X,center.Y+1,center.Z),width,height,out top)||!Project(new V3(center.X,center.Y-1,center.Z),width,height,out bottom))return false;
 double h=Math.Abs(bottom.Y-top.Y);return h>=2&&Math.Abs(cross.X-torso.X)<=h*.35&&Math.Abs(cross.Y-torso.Y)<=h*.45;
 }

}
}



