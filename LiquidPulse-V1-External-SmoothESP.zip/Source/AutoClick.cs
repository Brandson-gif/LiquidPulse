using System;
using System.Runtime.InteropServices;
using System.Windows.Threading;
namespace LiquidPulse {
public enum ClickAction { None, Press, Release }
public class ClickPulse {
 public bool Pressed {get;private set;}
 double releaseAt,next;
 public ClickAction Step(bool onTarget,double now,int cps){
 if(Pressed){if(!onTarget||now>=releaseAt){Pressed=false;return ClickAction.Release;}return ClickAction.None;}
 if(!onTarget)return ClickAction.None;
 if(now<next)return ClickAction.None;
 Pressed=true;releaseAt=now+10;next=now+1000.0/Math.Max(1,Math.Min(40,cps));return ClickAction.Press;
 }
 public void Reset(){Pressed=false;next=releaseAt=0;}
}
public partial class AppWindow {
 [DllImport("winmm.dll")] static extern uint timeBeginPeriod(uint ms);
 [DllImport("winmm.dll")] static extern uint timeEndPeriod(uint ms);
 readonly ClickPulse clickPulse=new ClickPulse();
 DispatcherTimer clickTimer;
 long triggerGate;
 double triggerGateUntil,triggerAcquired;
 bool timerPrecision;
 void FireTrigger(long id){
 double now=triggerTime.Elapsed.TotalMilliseconds;
 if(!s.Trigger||capture!=null||id==0){StopTrigger();return;}
 if(triggerGate==0)triggerAcquired=now;
 triggerGate=id;triggerGateUntil=now+Math.Min(100,Math.Max(30,1800.0/s.Hz));
 if(clickTimer==null){clickTimer=new DispatcherTimer(DispatcherPriority.Input);clickTimer.Interval=TimeSpan.FromMilliseconds(2);clickTimer.Tick+=delegate{PumpTrigger();};}
 if(!clickTimer.IsEnabled){timerPrecision=timeBeginPeriod(1)==0;clickTimer.Start();}
 PumpTrigger();
 }
 void PumpTrigger(){
 double now=triggerTime.Elapsed.TotalMilliseconds;
 bool gate=s.Trigger&&connected&&!closing&&capture==null&&triggerGate!=0&&now<=triggerGateUntil&&gameWindow!=IntPtr.Zero&&GetForegroundWindow()==gameWindow&&DateTime.UtcNow-sampled<TimeSpan.FromMilliseconds(Math.Min(150,Math.Max(50,1800.0/s.Hz)));
 if(!gate){StopTrigger();return;}
 if(!clickPulse.Pressed&&Down(1)){triggerAcquired=now;return;}
 ClickAction action=clickPulse.Step(true,now,s.TriggerCps);
 if(action!=ClickAction.None&&!SendClick(action)){
 s.Trigger=false;StopTrigger();status.Text="Click input blocked; triggerbot disabled";
 }
 }
 bool SendClick(ClickAction action){var input=new[]{new INPUT{type=0,mouse=new MOUSEINPUT{flags=action==ClickAction.Press?2u:4u}}};return SendInput(1,input,Marshal.SizeOf(typeof(INPUT)))==1;}
 void StopTrigger(){
 triggerGate=0;
 // Release only an automatic press owned by this click loop.
 if(clickPulse.Pressed)SendClick(ClickAction.Release);
 clickPulse.Reset();
 if(clickTimer!=null)clickTimer.Stop();
 if(timerPrecision){timeEndPeriod(1);timerPrecision=false;}
 }
}
}


