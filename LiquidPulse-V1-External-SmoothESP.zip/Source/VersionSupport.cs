using System;
using System.IO;
using System.Net;
using System.Text;
using System.Collections.Generic;
using System.Web.Script.Serialization;
namespace LiquidPulse {
public static class VersionSupport {
 static Dictionary<string,long[]> cache=new Dictionary<string,long[]> {
 {"version-f0ea5da9412f4e35",new long[]{149645664,143928888}},
 {"version-4ea8e85481e34f46",new long[]{150530408,144775176}}
 };
 static readonly Dictionary<string,long> required=new Dictionary<string,long>{
 {"FakeDataModel.RealDataModel",504},{"VisualEngine.ViewMatrix",432},
 {"Instance.ChildrenStart",112},{"Instance.ChildrenEnd",8},{"Instance.NameContainer",104},{"Instance.ClassDescriptor",24},{"Instance.ClassName",8},{"Instance.Parent",96},
 {"Player.LocalPlayer",280},{"Player.ModelInstance",672},{"Player.Team",736},{"Player.Neutral",980},
 {"BasePart.Primitive",376},{"BasePart.Transparency",280},
 {"Primitive.Position",212},{"Primitive.Rotation",176},{"Primitive.Size",452},{"Primitive.Flags",446},{"PrimitiveFlags.Anchored",2},
 {"Model.PrimaryPart",576},{"Workspace.CurrentCamera",1184},{"Camera.Position",228},{"Camera.CameraSubject",176},
 {"Humanoid.Health",388},{"DataModelMesh.Offset",160},{"DataModelMesh.Scale",172},{"Team.BrickColor",160},
 {"IntValue.Value",160},{"BrickColorValue.Value",160}
 };
 static long Number(object value){if(value is string){string s=(string)value;if(s.StartsWith("0x"))return Convert.ToInt64(s.Substring(2),16);}return Convert.ToInt64(value);}
 public static long[] Validate(string version,string json){
 var root=new JavaScriptSerializer{MaxJsonLength=2097152}.Deserialize<Dictionary<string,object>>(json);
 if(!root.ContainsKey("Roblox Version")||Convert.ToString(root["Roblox Version"])!=version)throw new IOException("Offset file does not match the running client");
 var groups=(Dictionary<string,object>)root["Offsets"];
 foreach(var pair in required){var path=pair.Key.Split('.');if(!groups.ContainsKey(path[0]))throw new IOException("Layout missing "+pair.Key);var group=(Dictionary<string,object>)groups[path[0]];if(!group.ContainsKey(path[1])||Number(group[path[1]])!=pair.Value)throw new IOException("Layout changed: "+pair.Key+" — application update required");}
 long dm=Number(((Dictionary<string,object>)groups["FakeDataModel"])["Pointer"]),ve=Number(((Dictionary<string,object>)groups["VisualEngine"])["Pointer"]);
 if(dm<65536||ve<65536||dm>0x100000000L||ve>0x100000000L)throw new IOException("Invalid global pointers");
 return new[]{dm,ve};
 }
 public static long[] Resolve(string version){
 if(string.IsNullOrEmpty(version)||!System.Text.RegularExpressions.Regex.IsMatch(version,"^version-[a-fA-F0-9]{16}$"))throw new IOException("Unrecognized Roblox build identity");
 lock(cache){long[] known;if(cache.TryGetValue(version,out known))return known;}
 ServicePointManager.SecurityProtocol|=SecurityProtocolType.Tls12;
 var request=(HttpWebRequest)WebRequest.Create("https://rbxoffsets.com/api/v1/windows/offsets/"+version+"/json");
 request.Timeout=5000;request.ReadWriteTimeout=5000;request.UserAgent="LiquidPulse-VersionCheck/1.0";
 string json;using(var response=request.GetResponse())using(var stream=response.GetResponseStream())using(var memory=new MemoryStream()){byte[] buffer=new byte[8192];int count;while((count=stream.Read(buffer,0,buffer.Length))>0){if(memory.Length+count>2097152)throw new IOException("Offset response too large");memory.Write(buffer,0,count);}json=Encoding.UTF8.GetString(memory.ToArray());}
 var result=Validate(version,json);lock(cache){cache[version]=result;}return result;
 }
}
}
