$ErrorActionPreference = 'Stop'
$framework = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319'
$destination = Split-Path $PSScriptRoot -Parent
& "$framework\csc.exe" /nologo /target:winexe /platform:x64 /optimize+ "/out:$destination\LiquidPulse-V1-External-SmoothESP.exe" "/reference:$framework\WPF\PresentationFramework.dll" "/reference:$framework\WPF\PresentationCore.dll" "/reference:$framework\WPF\WindowsBase.dll" "/reference:$framework\System.Xaml.dll" "/reference:$framework\System.Web.Extensions.dll" "$PSScriptRoot\LiquidPulse.cs" "$PSScriptRoot\Realtime.cs" "$PSScriptRoot\Discovery.cs" "$PSScriptRoot\TeamsTrigger.cs" "$PSScriptRoot\AutoClick.cs" "$PSScriptRoot\WallCheck.cs" "$PSScriptRoot\BodyRay.cs" "$PSScriptRoot\VersionSupport.cs"
if ($LASTEXITCODE -ne 0) { throw 'Compilation failed' }
Write-Output "Built $destination\LiquidPulse-V1-External-SmoothESP.exe"










