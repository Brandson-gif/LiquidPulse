LiquidPulse V1-External - Smooth ESP update

Extract the ZIP, close any older copy, and run LiquidPulse-V1-External-SmoothESP.exe.
Join a game, click Connect on Home, then return focus to Roblox.
ESP now enables on a successful connection. The ESP toggle is available on the ESP tab and through its keybind.
Your saved bindings are preserved. On this computer ESP is assigned to F8;
new settings use X. Aimbot and triggerbot still start disabled.

Changes:
- Overlay drawing follows WPF display-composition frames instead of a dispatcher timer.
- Data collection remains rate-limited to the configured Hz (120 by default),
  with at most one pending read. Actual display rate depends on the monitor/WPF.
- Status text refreshes four times per second to reduce layout work.
- Window bounds change only when needed; the game window handle refreshes periodically.
- Status shows whether ESP is enabled and its actual saved key.

Validation: build and all six tabs in both themes passed. The live read-only
probe found actors and on-screen projections; details in Validation.txt.
No automated input was sent. End-to-end visual smoothness has not been measured,
and this does not guarantee a particular FPS or detection in every game.
Compatibility checks and geometry limitations of the previous build still apply.
No anti-cheat hiding or bypass features have been added.

Source and Build.ps1 are included. Windows x64 / .NET Framework 4.8.
